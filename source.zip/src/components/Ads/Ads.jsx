import React from 'react'

const Ads = () => {
  return (
    <div>Ads</div>
  )
}

export default Ads