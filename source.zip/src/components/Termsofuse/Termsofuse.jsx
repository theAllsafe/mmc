import React from 'react'

const Termsofuse = () => {
  return (
    <div>Termsofuse</div>
  )
}

export default Termsofuse