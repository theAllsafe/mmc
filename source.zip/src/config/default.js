const config = {
  base_url: "http://localhost:3002",
  // base_url: "https://mmcbackend123.herokuapp.com/",
};

export default config;
